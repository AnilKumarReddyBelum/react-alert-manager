import React from 'react';
import { NotificationContainer, NotificationManager } from 'react-notifications';
import 'react-notifications/lib/notifications.css';
import AlertManagerComponent from './AlertManagerComponent';
import AlertManager from './AlertManager';

class App extends React.Component {

    constructor(props) {
        super(props);
    }

    createNotification = (type) => {
        return () => {
            AlertManager.success('Success', 'ACTION SUCCEEDED');
        };
    };



    render() {
        return (<div>

            <button className='btn btn-info'
                onClick={this.createNotification('success')}>Info
                </button>
            <NotificationContainer />
        </div>);
    }
}

export default App;